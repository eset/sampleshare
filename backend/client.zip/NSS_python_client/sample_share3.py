"""
Contains Python client implementation of the Norman Sample Sharing
framework class
@copyright CrowdStrike, Inc. 2013
@organization CrowdStrike, Inc.

Copyright (C) 2013 CrowdStrike, Inc.
This file is subject to the terms and conditions of the GNU General Public
License version 2.  See the file COPYING in the main directory for more
Details.

Edited and converted to Python3 in ESET (2018)

"""

import os
import sys
import ssl
import urllib
import urllib.request
import urllib.parse
import logging
import subprocess
import gzip
import hashlib
import base64
import tempfile
import shutil

# Logger instance
LOGGER = logging.getLogger("SampleShare")

#when using first time, set your GPG passphrase
GPG_PASSPHRASE = ""
assert GPG_PASSPHRASE, "ERROR: Set your GPG passphrase!"

class SampleShareError(Exception):
    """ Base class for all errors
    """
    pass


class SampleShare():
    """ Implementation of Normal Sample Sharing Framework client in python

    Initializes a new instance of the Norman Sample Sharing Framework object
    Args:
        url: URL of the NSSF server
        username: Username to use for authentication
        password: Password to use for authentication
    """

    def __init__(self, url, username, password):
        self.url = url
        self.username = username
        self.password = password

    def create_opener(self, url):
        """
        Creates a URL opener with the proper credentials

        Args:
            url: The URL to which to connect

        Returns:
            An instance of a URL opener that can authenticate against the URL
            with the configured basic auth
        """
        #authentication handler
        password_manager = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        password_manager.add_password(None, url, self.username, self.password)
        authentication_handler = urllib.request.HTTPBasicAuthHandler(password_manager)
        #https handler
        context = ssl.create_default_context(purpose=ssl.Purpose.CLIENT_AUTH)
        https_handler = urllib.request.HTTPSHandler(context=context)
        opener = urllib.request.build_opener(authentication_handler, https_handler)
        return opener

    def create_nss_request(self, url):
        """
        Creates a url Request

        Args:
            url: The URL to which to connect

        Returns:
            An url request with authentification against the URL
            with the configured basic auth
        """

        request_url = urllib.request.Request(url)
        request_url.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) "
                               "Gecko/20100101 Firefox/58.0")
        request_url.add_header("Authorization", "Basic {}".format(
            base64.encodebytes("{}:{}".format(
                self.username, self.password).encode()).decode().replace("\n", "")))
        return request_url

    @staticmethod
    def gpg_decrypt(encrypted, decrypted):
        """
        Calls gpg to decrypt downloaded

        Args:
            encrypted: filename of encrypted file
            decrypted: output filename, where to

        Returns: Path to encrypted file
        """
        subprocess.check_call(["gpg", "--skip-verify", "--batch",
                               "--quiet", "--passphrase={}".format(GPG_PASSPHRASE),
                               "--no-mdc-warning", "-o", decrypted,
                               "--decrypt", encrypted])
        return decrypted

    def get_supported_compression(self):
        """
        Calls web service to get the list of compression supported by the server

        Returns:
            List of compression options available on the NSSF server (typically "zlib")
        """

        request_url = ("https://{}?action=get_supported_compression&user={}".format(
            self.url, self.username))

        opener = self.create_opener(request_url)
        response_data = opener.open(request_url).read()
        # Compression methods are separated by "\r\n"s
        supported_compression_methods = response_data.strip().split("\r\n")
        return supported_compression_methods

    def _get_file_list(self, from_date_utc, to_date_utc, extra_attributes=""):
        # (Too many local variables) pylint: disable=R0914
        """
        Internal function to get the list of files from the server

        Args:
            from_date_utc: The start date for the window from which to get
            files
            to_date_utc: The end date for the window from which to get files
            extra_attributes: Extra attributes added to the URL (used for
            specifying the clean list)

        Returns:
            List of items in hashtable form
        """

        url = ("http://{}?action=getlist&user={}{}&from={}&to={}".format(
            self.url,
            self.username,
            extra_attributes,
            urllib.parse.quote(from_date_utc),
            urllib.parse.quote(to_date_utc)
            ))

        LOGGER.info('Getting file list from %s to %s',
                    from_date_utc, to_date_utc)
        opener = self.create_opener(url)
        # create request for url
        request_url = self.create_nss_request(url)
        response = opener.open(request_url)

        with tempfile.TemporaryDirectory() as temp_dir:
            encrypted_filename = os.path.join(temp_dir, "filelist.txt.gpg")
            filelist_filename = os.path.join(temp_dir, "filelist.txt")
            # Write response to file
            with open(encrypted_filename, "wb") as output_file:
                while True:
                    response_data = response.read(4096)  # BLOCK_SIZE
                    if not response_data:
                        break
                    output_file.write(response_data)

            # Decrypt response with GPG
            self.gpg_decrypt(encrypted_filename, filelist_filename)

            # Read decrypted response
            if os.path.isfile(filelist_filename):
                LOGGER.debug('There is new file created with size %d', os.path.getsize(
                    filelist_filename))

            with open(filelist_filename, "r") as input_file:
                file_list_contents = input_file.read()

        file_rows = file_list_contents.strip().split("\n")
        file_list = []
        for file_row in file_rows:
            file_data = file_row.split(":")
            if len(file_data) == 2:
                file_list.append({"file_identifier": file_data[0],
                                  "file_size": file_data[1]})

        return file_list

    def get_malware_list(self, from_date_utc, to_date_utc):
        """
        Get the list of malware files in the given time range from the server

        Args:
            from_date_utc: The start date for the window from which to get files
            to_date_utc: The end date for the window from which to get files

        Returns:
            List of items in hashtable form
        """
        return self._get_file_list(from_date_utc, to_date_utc)

    @staticmethod
    def get_hash_type(hash_value):
        """
        Determines the hash type based on the length of the string
        Args:
            hash: The hash for which to determine the type

        Returns:
            string containing the type of hash
        """
        hash_type = {32: "md5", 40: "sha1", 64: "sha256"} \
            .get(len(hash_value), None)
        if not hash_type:
            raise SampleShareError("Unknown hash type: {}".format(hash_value))
        return hash_type

    @staticmethod
    def get_hash_length(hash_type):
        """
        Determines the number of bytes in a hash
        Args:
            hash: The hash for which to determine the length

        Returns:
            Number of bytes in the given hash
        """
        hash_length = {"md5": 16, "sha1": 20,
                       "sha256": 32}.get(hash_type, None)
        if not hash_length:
            raise SampleShareError("Unknown hash type: {}".format(hash_type))
        return hash_length

    @staticmethod
    def _process_file(destination_filename, response, compression, file_identifier):
        """
        Handles taking the file contents, decrypting, and decompressing them

        Args:
            destination_filename: The filename of the final, decrypted and
                decompressed file
            file_data: The encrypted, potentially compressed file contents
            compression: The compression used on the file data
            file_identifier: The expected hash of the file
        """
        #Too many local variables, Too many branches pylint: disable=R0914, R0912
        with tempfile.TemporaryDirectory() as temp_dir:
            encrypted_filename = os.path.join(temp_dir, "encrypted.gpg")
            decrypted_filename = os.path.join(temp_dir, "decrypted")
            decompressed_filename = os.path.join(temp_dir, "decompressed")
            # Write response to file
            with open(encrypted_filename, "wb") as output_file:
                while True:
                    file_data = response.read(4096) # BLOCK_SIZE
                    if not file_data:
                        break
                    output_file.write(file_data)
                    # Check for an error from the server
                    if len(file_data) < 200 and file_data.startswith(b"ERROR! => "):
                        raise SampleShareError("Server error: {}".format(file_data[10:]))

            # Decrypt response with GPG
            SampleShare.gpg_decrypt(encrypted_filename, decrypted_filename)

            # If it's compressed, decompress it
            if not compression:
                shutil.move(decrypted_filename, decompressed_filename)
            elif compression == "zlib":
                input_file = gzip.open(decrypted_filename, "rb")
                try:
                    with open(decompressed_filename, "wb") as output_file:
                        decompressed_data = input_file.read()
                        output_file.write(decompressed_data)
                finally:
                    input_file.close()
            else:
                raise SampleShareError(
                    "unknown compression: {}".format(compression))

            # Verify the data is the expected file
            hash_type = SampleShare.get_hash_type(file_identifier)
            if hash_type == "md5":
                hash_generator = hashlib.md5()
            elif hash_type == "sha1":
                hash_generator = hashlib.sha1()
            elif hash_type == "sha256":
                hash_generator = hashlib.sha256()
            else:
                raise SampleShareError(
                    "Unknown hash type: {}".format(hash_type))
            with open(decompressed_filename, "rb") as input_file:
                hash_generator.update(input_file.read())
                file_hash = hash_generator.hexdigest()
            if file_hash.lower() != file_identifier.lower():
                raise SampleShareError(
                    "Hash of file {} doesn't match file identifier {}".format(
                        file_hash, file_identifier))

            # Create a hard link that effectively copies the output to the
            # destination location
            if os.path.exists(destination_filename):
                os.remove(destination_filename)
            os.makedirs(os.path.dirname(destination_filename), exist_ok=True)
            shutil.move(decompressed_filename, destination_filename)

    def get_file(self, file_identifier, destination_filename, compression=None):
        """
        Downloads the given file from the server

        Args:
            file_identifier: The hash of the file to download
            destination_filename: The filename to which to download it
            compression: The compression to use. Must be supported
                byserver. Typically: None or "zlib"
        """

        compression_option = ("&compression={}".format(
            compression if compression else ""))
        hash_type = self.get_hash_type(file_identifier)
        url = ("http://{}?action=getfile&user={}&{}={}{}".format(
            self.url, self.username, hash_type, file_identifier, compression_option))

        # create opener for url
        opener = self.create_opener(url)
        # create request for url
        request_url = self.create_nss_request(url)
        response = opener.open(request_url, timeout=120)

        self._process_file(destination_filename, response,
                           compression, file_identifier)


def list_samples(cmdl_args):
    """
    Command line parser function for listing files

    Args:
        cmdl_args: The command line arguments
    """
    s_s = SampleShare("10.101.87.11/api",
                      cmdl_args.username,
                      cmdl_args.password)
    print("{}".format(s_s.get_malware_list(cmdl_args.start, cmdl_args.end)))


def list_and_download_samples(cmdl_args):
    """
    Command line parser function for listing and downloading files one by one

    Args:
        cmdl_args: The command line arguments
    """

    LOGGER.debug('destination - %s\ncompression - %s',
                 cmdl_args.destination, cmdl_args.compression)

    s_s = SampleShare("10.101.87.11/api",
                      cmdl_args.username,
                      cmdl_args.password)

    filelist = s_s.get_malware_list(cmdl_args.start, cmdl_args.end)

    list_we_need = list()
    for item in filelist:
        list_we_need.append(item["file_identifier"])
    LOGGER.debug("%d -files in downloaded list", len(list_we_need))

    # download files from list
    for file in list_we_need:
        i = 0
        while True:
            try:
                if i > 3:
                    LOGGER.debug("%s cannot be downloaded", file)
                    break
                else:
                    s_s.get_file(file, os.path.join(
                        cmdl_args.destination, file))
                    LOGGER.debug("%s - Ok", file)
                    break
            except urllib.error.URLError as u_e:
                LOGGER.debug("%d. attempt: %s - cannot download the file:"
                             " %s - trying again...", i + 1, file, u_e)
                i += 1


#----------------------------------------------------------------------
def main():
    """
    Main function
    """
    # (Line too long) pylint: disable=C0301
    # Example of command lines:
    # - sample_share3.py --username=username --password=password list_samples "2018-04-20 00:00:00" ""2018-04-21 00:00:00""
    # - sample_share3.py --username=username --password=password list_download_malware "2018-04-20 00:00:00" "2018-04-21 00:00:00" --destination "$destination_directory"

    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.DEBUG)
    stdout_log_formater = logging.Formatter("%(message)s")
    stdout_handler.setFormatter(stdout_log_formater)
    LOGGER.addHandler(stdout_handler)
    LOGGER.setLevel(logging.DEBUG)

    # Pull the creds from the environment
    username = os.environ.get("nssf_username", None)
    password = os.environ.get("nssf_password", None)

    import argparse
    parser = argparse.ArgumentParser(description='Python NSSF client')
    parser.add_argument('--username', default=username, help='Username')
    parser.add_argument('--password', default=password, help='Password')
    subparsers = parser.add_subparsers(help="sub-command help")

    parser_list_samples = subparsers.add_parser("list_samples",
                                                help="Lists samples")
    parser_list_samples.add_argument("start",
                                     help="Start date")
    parser_list_samples.add_argument("end",
                                     help="End date")
    parser_list_samples.set_defaults(func=list_samples)

    parser_list_and_download = subparsers.add_parser("list_download_malware",
                                                     help="Lists and download Malware")
    parser_list_and_download.add_argument("start",
                                          help="Start date")
    parser_list_and_download.add_argument("end",
                                          help="End date")
    parser_list_and_download.add_argument('--destination', required=True,
                                          help='Destinaton directory for files to download')
    parser_list_and_download.add_argument('--compression', default=None,
                                          help='Compression to use when " \
                                          "downloading samples')
    parser_list_and_download.set_defaults(func=list_and_download_samples)
    
    if len(sys.argv) == 1:
        parser.print_help(sys.stderr)
        sys.exit(1)
    
    args = parser.parse_args()
    args.func(args)

if __name__ == '__main__':
    main()
